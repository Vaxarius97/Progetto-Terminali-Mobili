#include <stdio.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <malloc.h>

#define PORT 4459

void azzera_buffer(char*);

struct product_list {
    char *nome;
    char *negozio;
    char *prezzo;
};

struct store_list{
    char *nome;
    char *proprietario;
    char *indirizzo;
};

int main() {
    int risposta, connectsocket;
    struct sockaddr_in servAddr;
    char *buffer, *tmp;

    printf("[+] - Avvio dell' applicazione.\n");

    buffer = (char*) malloc(1024 * sizeof(char));


    memset(&servAddr,'\0',sizeof(servAddr));
    servAddr.sin_family = AF_INET;
    servAddr.sin_port = htons(PORT);
    servAddr.sin_addr.s_addr = htonl(INADDR_ANY);

    for ( ; ; ) {
        printf("\n[+] - Cosa vuoi fare?\n1) Aggiungi Negozio\n2) Elimina Negozio\n3) Aggiungi Prodotto\n4) Elimina Prodotto\n");

        scanf("%d", &risposta);

        if (risposta == 1){
            if ((connectsocket = socket(AF_INET, SOCK_STREAM, 0)) < 0){
                perror("errore socket.\n");
                exit(1);
            }

            if (connect(connectsocket,(struct sockaddr*) &servAddr, sizeof(servAddr)) < 0){
                perror("errore connessione.\n");
                exit(1);
            }

            printf("[+] - Connessione effettuata.\n");

            strcpy(buffer, "aggiungi");

            if (send(connectsocket, buffer, strlen(buffer), 0) < 0){
                perror("errore invio.\n");
                exit(1);
            }

            azzera_buffer(buffer);

            if (recv(connectsocket,buffer,1024,0) < 0){
                perror("errore ricezione.\n");
                exit(1);
            }

            printf("[+] - Il server N ha detto: %s", buffer);

            printf("[+] - Inserisci il nome del proprietario: ");
            tmp = (char*) malloc(256 * sizeof(char));
            scanf(" %[^\n]", tmp);
            strcpy(buffer,tmp);
            strcat(buffer,"|");
            tmp = '\0';

            printf("[+] - Inserisci il nome del negozio: ");
            tmp = (char*) malloc(256 * sizeof(char));
            scanf(" %[^\n]", tmp);
            strcat(buffer,tmp);
            strcat(buffer,"|");
            tmp = '\0';

            printf("[+] - Inserisci l'indirizzo del negozio: ");
            tmp = (char*) malloc(256 * sizeof(char));
            scanf(" %[^\n]", tmp);
            strcat(buffer,tmp);
            strcat(buffer,"|");
            tmp = '\0';

            if(send(connectsocket,buffer,strlen(buffer),0) < 0){
                perror("errore invio.");
                exit(1);
            }

            azzera_buffer(buffer);

            if (recv(connectsocket, buffer, 1024, 0) < 0){
                perror("errore.\n");
                exit(1);
            }

            printf("%s\n", buffer);

            azzera_buffer(buffer);

            close(connectsocket);
        }

        if (risposta == 2){
            if ((connectsocket = socket(AF_INET, SOCK_STREAM, 0)) < 0){
                perror("errore socket.\n");
                exit(1);
            }
            if (connect(connectsocket,(struct sockaddr*) &servAddr, sizeof(servAddr)) < 0){
                perror("errore connessione.\n");
                exit(1);
            }
            strcpy(buffer, "rimuovi");

            if (send(connectsocket, buffer, strlen(buffer), 0) < 0){
                perror("errore invio.\n");
                exit(1);
            }

            azzera_buffer(buffer);
            if (recv(connectsocket, buffer, 1024, 0) < 0) {
                perror("errore ricezione.\n");
                exit(1);
            }

            printf("[+] - Il server N ha detto: %s", buffer);

            printf("[+] - Inserisci il nome del negozio: ");
            tmp = (char*) malloc(256 * sizeof(char));
            scanf(" %[^\n]", tmp);
            strcpy(buffer,tmp);
            tmp = '\0';

            if (send(connectsocket, buffer, strlen(buffer), 0) < 0){
                perror("errore invio.\n");
                exit(1);
            }

            azzera_buffer(buffer);

            if (recv(connectsocket, buffer, 1024, 0) < 0){
                perror("errore.\n");
                exit(1);
            }

            printf("%s\n", buffer);

            azzera_buffer(buffer);

            close(connectsocket);
        }

        if (risposta == 3){
            if ((connectsocket = socket(AF_INET, SOCK_STREAM, 0)) < 0){
                perror("errore socket.\n");
                exit(1);
            }
            if (connect(connectsocket,(struct sockaddr*) &servAddr, sizeof(servAddr)) < 0){
                perror("errore connessione.\n");
                exit(1);
            }
            strcpy(buffer, "aggiungiP");

            if (send(connectsocket, buffer, strlen(buffer), 0) < 0){
                perror("errore invio.\n");
                exit(1);
            }

            azzera_buffer(buffer);

            if (recv(connectsocket,buffer,1024,0) < 0){
                perror("errore ricezione.\n");
                exit(1);
            }

            printf("[+] - Il server N ha detto: %s", buffer);

            printf("[+] - Inserisci il nome del Prodotto: ");
            tmp = (char*) malloc(256 * sizeof(char));
            scanf(" %[^\n]", tmp);
            strcpy(buffer,tmp);
            strcat(buffer,"|");
            tmp = '\0';

            printf("[+] - Inserisci il nome del Negozio: ");
            tmp = (char*) malloc(256 * sizeof(char));
            scanf(" %[^\n]", tmp);
            strcat(buffer,tmp);
            strcat(buffer,"|");
            tmp = '\0';

            printf("[+] - Inserisci il Prezzo: ");
            tmp = (char*) malloc(256 * sizeof(char));
            scanf(" %[^\n]", tmp);
            strcat(buffer,tmp);
            strcat(buffer,"|");
            tmp = '\0';

            if(send(connectsocket,buffer,strlen(buffer),0) < 0){
                perror("errore invio.");
                exit(1);
            }

            azzera_buffer(buffer);

            if (recv(connectsocket, buffer, 1024, 0) < 0){
                perror("errore.\n");
                exit(1);
            }

            printf("%s\n", buffer);

            azzera_buffer(buffer);

            close(connectsocket);
        }

        if (risposta == 4){
            if ((connectsocket = socket(AF_INET, SOCK_STREAM, 0)) < 0){
                perror("errore socket.\n");
                exit(1);
            }
            if (connect(connectsocket,(struct sockaddr*) &servAddr, sizeof(servAddr)) < 0){
                perror("errore connessione.\n");
                exit(1);
            }
            strcpy(buffer, "rimuoviP");

            if (send(connectsocket, buffer, strlen(buffer), 0) < 0){
                perror("errore invio.\n");
                exit(1);
            }

            azzera_buffer(buffer);
            if (recv(connectsocket, buffer, 1024, 0) < 0) {
                perror("errore ricezione.\n");
                exit(1);
            }

            printf("[+] - Il server N ha detto: %s", buffer);

            printf("[+] - Inserisci il nome del prodotto: ");
            tmp = (char*) malloc(256 * sizeof(char));
            scanf(" %[^\n]", tmp);
            strcpy(buffer,tmp);
            tmp = '\0';

            if (send(connectsocket, buffer, strlen(buffer), 0) < 0){
                perror("errore invio.\n");
                exit(1);
            }

            azzera_buffer(buffer);

            if (recv(connectsocket, buffer, 1024, 0) < 0){
                perror("errore.\n");
                exit(1);
            }

            printf("%s\n", buffer);

            azzera_buffer(buffer);

            close(connectsocket);
        }
    }
    return 0;
}

void azzera_buffer (char* buff){
    int i = 0;
    while (i < 1024){
        buff[i] = '\0';
        i++;
    }
}
