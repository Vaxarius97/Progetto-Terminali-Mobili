#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <malloc.h>
#include <sys/socket.h>
#include <arpa/inet.h>

#define PORT 4455
#define PORT1 4456

int create_socket_server(int, struct sockaddr_in, int);
int connetti_client (int, struct sockaddr_in, int);
void azzera_buffer(char*);
void decoder (char*);

struct product_list {
    char nome[50];
    char negozio[50];
    char prezzo[6];
};

int main() {

    int serverSocket, connectSocket, server_m_sock;
    int *num_elem=0;
    struct sockaddr_in servaddr, servMAddr, newAddr;
    socklen_t addrSize;
    pid_t childpid;
    char* buffer;

    buffer = (char *) malloc(1024 * sizeof(char));

    serverSocket = create_socket_server(serverSocket, servaddr, PORT);
    addrSize =sizeof(newAddr);

    for( ; ; ){
        if((connectSocket = accept(serverSocket, (struct sockaddr *) &newAddr, &addrSize)) < 0){
            perror("[-] - Errore di connessione.\n");
            exit(1);
        }

        if((childpid = fork())==0) {

            printf("[+] - Client connesso.\n");

            //Connessione al serer M
            if ((server_m_sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
                perror("[-] - Errore Socket!\n");
                exit(1);
            }

            memset(&servMAddr, '\0', sizeof(servMAddr));
            servMAddr.sin_family = AF_INET;
            servMAddr.sin_port = htons(PORT1);
            servMAddr.sin_addr.s_addr = htonl(INADDR_ANY);

            if (connect(server_m_sock, (struct sockaddr *) &servMAddr, sizeof(servMAddr)) < 0) {
                perror("[-] - Errore di connessione!\n");
                exit(1);
            }

            azzera_buffer(buffer);
            strcpy(buffer, "ServerC");

            if (send(server_m_sock, buffer, strlen(buffer), 0) < 0) {
                perror("errore.\n");
                exit(1);
            }

            azzera_buffer(buffer);

            if (recv(server_m_sock, buffer, 1024, 0) < 0) {
                perror("errore\n");
                exit(1);
            }

            if (send(connectSocket, buffer, strlen(buffer), 0) < 0) {
                perror("errore\n");
                exit(1);
            }

            num_elem = (int *) buffer;
            int num2 = *num_elem;
            azzera_buffer(buffer);

            if (recv(connectSocket, buffer, 1024, 0) < 0) {
                perror("errore\n");
                exit(1);
            }

            //printf("%d\n", *num_elem);
            if (send(server_m_sock, buffer, strlen(buffer), 0) < 0) {
                perror("errore\n");
                exit(1);
            }

            for (int i = 0; i < num2; i++) {
                azzera_buffer(buffer);

                if (recv(server_m_sock, buffer, 1024, 0) < 0) {
                    perror("errore\n");
                    exit(1);
                }
                if (send(connectSocket, buffer, strlen(buffer), 0) < 0) {
                    perror("errore\n");
                    exit(1);
                }

                azzera_buffer(buffer);

                if (recv(connectSocket, buffer, 1024, 0) < 0) {
                    perror("errore\n");
                    exit(1);
                }
                if (send(server_m_sock, buffer, strlen(buffer), 0) < 0) {
                    perror("errore\n");
                    exit(1);
                }
            }
        }
        close(connectSocket);
    }
}

int create_socket_server (int sock, struct sockaddr_in srvr, int port_num){
    printf("[+] - Avvio del server\n");
    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0){
        perror("[-] - Errore Socket\n");
        exit(1);
    }

    srvr.sin_family = AF_INET;
    srvr.sin_port = htons(port_num);
    srvr.sin_addr.s_addr = htonl(INADDR_ANY);

    printf("[+] - Socket creato correttamente, in attesa di connessioni...\n");
    if (bind(sock, (struct sockaddr *) &srvr, sizeof(srvr)) < 0){
        perror("[-] - Errore binding.\n");
        exit(1);
    }

    if (listen(sock, PORT) < 0){
        perror("[-] Errore nell' ascolto.\n");
        exit(1);
    }

    return sock;
}

int connetti_client (int sock, struct sockaddr_in sA, int port_num){
    printf("[+] - Avvio dell' applicazione.\n\n");

    if ((sock = socket(AF_INET, SOCK_STREAM,0)) < 0){
        perror("[-] - Errore Socket!\n");
        exit(1);
    }

    memset(&sA, '\0', sizeof(sA));
    sA.sin_family = AF_INET;
    sA.sin_port = htons(port_num);
    sA.sin_addr.s_addr = htonl(INADDR_ANY);

    return sock;
}

void azzera_buffer (char* buff){
    int i = 0;
    while (i < 1024){
        buff[i] = '\0';
        i++;
    }
}

void decoder (char* buff){
    int i=0,j=0, verify_nom=0, verify_neg=0, verify_pirce=0;
    char *nome, *negozio, *prezzo, *index;

    nome = (char *) malloc(50 * sizeof(char));
    negozio = (char *) malloc(50 * sizeof(char));
    prezzo = (char *) malloc(6 * sizeof(char));
    index = (char *) malloc(50 * sizeof(char));

    while (buff[i] != '\0'){
        if (buff[i] == '|'){
            if(verify_nom == 0){
                strcpy(nome, index);
                verify_nom = 1;
                azzera_buffer(index);
                j=0;
            } else if( verify_neg == 0){
                strcpy(negozio, index);
                verify_neg = 1;
                azzera_buffer(index);
                j=0;
            } else if (verify_pirce == 0){
                strcpy(prezzo, index);
                verify_pirce = 1;
                azzera_buffer(index);
                j=0;
            }
            i++;
        }
        index[j] = buff[i];
        j++;
        i++;
    }
    printf("Nome: %s\nNegozio: %s\nPrezzo: %s€\n", nome,negozio,prezzo);
}

