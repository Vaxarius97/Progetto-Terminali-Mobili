#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <malloc.h>

#define PORT 4456

struct product_list {
    char *nome;
    char *negozio;
    char *prezzo;
    struct product_list *prox;
};

struct store_list{
    char nome[50];
    char proprietario[50];
    char indirizzo[50];
};


int create_socket_server(int, struct sockaddr_in, int);
int conta_elem(struct product_list*);
void azzera_buffer(char*);
void encoder(char*,char*,char*,char*);
void decoder2(char*, char*, char*, char*);
void inserisci_coda(struct product_list*, struct product_list*);
struct product_list *elimina_elem(struct product_list*,char*,int);

struct product_list *crea_lista();

int main() {
    int serverM_sock, connect_sock, num_elem, i = 0, found = 0;
    struct product_list *lista, *punt, *punt1;
    struct store_list lista_negozio[100];
    struct sockaddr_in servMAddr, newAddr;
    socklen_t addrSize;
    char *buffer;
    char nom[50], neg[50], adr[50];
    char *cNum_elem;
    pid_t childpid;

    lista = crea_lista();
    punt = lista;
    //stampa_lista(lista);

    punt1 = (struct product_list*) malloc(sizeof(struct product_list));
    punt1->nome = (char *) malloc(50 * sizeof(char));
    punt1->prezzo = (char *) malloc(6 * sizeof(char));
    punt1->negozio = (char *) malloc(50 * sizeof(char));

    cNum_elem = (char *) malloc(2 * sizeof(char));
    buffer = (char *) malloc(1024 * sizeof(char));

    serverM_sock = create_socket_server(serverM_sock, servMAddr, PORT);
    addrSize = sizeof(newAddr);

    for( ; ; ){

        printf("[+] - Socket in ascolto. In attesa di connessioni...\n");

        if((connect_sock = accept(serverM_sock, (struct sockaddr *) &newAddr, &addrSize)) < 0){
            perror("[-] - Errore di connessione.\n");
            exit(1);
        }

        if((childpid = fork()) == 0) {

            if (recv(connect_sock, buffer, 1024, 0) < 0) {
                perror("errore");
                exit(1);
            }

            if (strcmp(buffer, "ServerC") == 0) {
                printf("[+] - Server C connesso.\n");

                azzera_buffer(buffer);
                num_elem = conta_elem(lista);
                cNum_elem[0] = (char *) num_elem;
                strcpy(buffer, cNum_elem);

                if (send(connect_sock, buffer, strlen(buffer), 0) < 0) {
                    perror("[-] - Errore di scrittura.\n");
                    exit(1);
                }

                azzera_buffer(buffer);

                if (recv(connect_sock, buffer, 1024, 0) < 0) {
                    perror("errore\n");
                    exit(1);
                }

                printf("[+] - Lo stato del Server C è: %s", buffer);

                for (int i = 0; i < num_elem; i++) {
                    azzera_buffer(buffer);
                    encoder(buffer, punt->nome, punt->negozio, punt->prezzo);
                    if (send(connect_sock, buffer, strlen(buffer), 0) != strlen(buffer)) {
                        perror("[-] - Errore di scrittura.\n");
                        exit(1);
                    }

                    punt = punt->prox;

                    azzera_buffer(buffer);

                    if (recv(connect_sock, buffer, 1024, 0) < 0) {
                        perror("errore\n");
                        exit(1);
                    }
                }
                punt = lista;
                azzera_buffer(buffer);
            }

            if (strcmp(buffer, "ServerN") == 0) {
                //Codice Server N

                azzera_buffer(buffer);
                strcpy(buffer, "Cosa vuoi fare?\n");

                if (send(connect_sock, buffer, strlen(buffer), 0) < 0) {
                    perror("errore.\n");
                    exit(1);
                }

                azzera_buffer(buffer);

                if (recv(connect_sock, buffer, 1024, 0) < 0) {
                    perror("errore.\n");
                    exit(1);
                }

                if (strcmp(buffer, "aggiungi") == 0) {
                    azzera_buffer(buffer);
                    strcpy(buffer, "Pronto a ricevere i negozi.\n");

                    if (send(connect_sock, buffer, strlen(buffer), 0) < 0) {
                        perror("errore.\n");
                        exit(1);
                    }

                    azzera_buffer(buffer);

                    if (recv(connect_sock, buffer, 1024, 0) < 0) {
                        perror("errore.\n");
                        exit(1);
                    }

                    azzera_buffer(nom);
                    azzera_buffer(neg);
                    azzera_buffer(adr);

                    decoder2(buffer, nom, neg, adr);

                    strcpy(lista_negozio[i].proprietario, nom);
                    strcpy(lista_negozio[i].nome, neg);
                    strcpy(lista_negozio[i].indirizzo, adr);

                    i++;

                    azzera_buffer(nom);
                    azzera_buffer(neg);
                    azzera_buffer(adr);
                    azzera_buffer(buffer);

                    strcpy(buffer, "[+] - Negozio aggiunto correttamente.\n");

                    if (send(connect_sock,buffer,strlen(buffer),0) < 0){
                        perror("errore.\n");
                        exit(1);
                    }

                    azzera_buffer(buffer);

                } else if (strcmp(buffer, "rimuovi") == 0) {
                    azzera_buffer(buffer);
                    strcpy(buffer, "Inserire il nome del negozio da rimuovere.\n");

                    if (send(connect_sock, buffer, strlen(buffer), 0) < 0) {
                        perror("errore.\n");
                        exit(1);
                    }

                    azzera_buffer(buffer);

                    if (recv(connect_sock, buffer, 1024, 0) < 0) {
                        perror("errore.\n");
                        exit(1);
                    }

                    for (int j = 0; j < i; j++) {
                        if (strcmp(lista_negozio[j].nome, buffer) == 0) {
                            struct store_list tmp = lista_negozio[j];

                            if (j == i - 1) {
                                azzera_buffer(lista_negozio[j].nome);
                                azzera_buffer(lista_negozio[j].proprietario);
                                azzera_buffer(lista_negozio[j].indirizzo);
                            } else {
                                for (int k = j + 1; k <= i; k++) {
                                    lista_negozio[k - 1] = lista_negozio[k];
                                }
                            }
                            found = 1;
                            i--;
                        }
                    }

                    azzera_buffer(buffer);
                    if (found == 1) {
                        strcpy(buffer, "[+] - Negozio eliminato correttamente.\n");
                        found = 0;
                    } else {
                        strcpy(buffer, "[+] - Nessun negozio trovato.\n");
                    }

                    if (send(connect_sock, buffer, strlen(buffer), 0) < 0){
                        perror("errore.\n");
                        exit(1);
                    }

                    azzera_buffer(buffer);

                } else if (strcmp(buffer, "aggiungiP") == 0) {

                    azzera_buffer(buffer);
                    strcpy(buffer, "Pronto a ricevere i negozi.\n");

                    if (send(connect_sock, buffer, strlen(buffer), 0) < 0) {
                        perror("errore.\n");
                        exit(1);
                    }

                    azzera_buffer(buffer);

                    if (recv(connect_sock, buffer, 1024, 0) < 0) {
                        perror("errore.\n");
                        exit(1);
                    }

                    azzera_buffer(nom);
                    azzera_buffer(neg);
                    azzera_buffer(adr);

                    decoder2(buffer, nom, neg, adr);

                    /* while (lista != NULL){
                         lista = lista->prox;
                     }*/

                    strcpy(punt1->nome, nom);
                    strcpy(punt1->negozio, neg);
                    strcpy(punt1->prezzo, adr);

                    /*lista = chichiagnfottachirir;
                    lista = punt;*/

                    inserisci_coda(lista, punt1);

                    azzera_buffer(nom);
                    azzera_buffer(neg);
                    azzera_buffer(adr);
                    azzera_buffer(buffer);

                    strcpy(buffer, "[+] - Prodotto aggiunto correttamente.\n");

                    if (send(connect_sock, buffer, strlen(buffer), 0) < 0){
                        perror("errore.\n");
                        exit(1);
                    }

                    azzera_buffer(buffer);

                } else if (strcmp(buffer, "rimuoviP") == 0) {
                    azzera_buffer(buffer);
                    strcpy(buffer, "Inserire il nome del prodotto da eliminare.\n");

                    if (send(connect_sock, buffer, strlen(buffer), 0) < 0) {
                        perror("errore.\n");
                        exit(1);
                    }

                    azzera_buffer(buffer);

                    if (recv(connect_sock, buffer, 1024, 0) < 0) {
                        perror("errore.\n");
                        exit(1);
                    }

                    lista = elimina_elem(lista, buffer, found);

                    azzera_buffer(buffer);

                    if(found == 1){
                        strcpy(buffer, "[+] - Prodotto eliminato correttamente.\n");
                        found = 0;
                    } else {
                        strcpy(buffer, "[+] - Nessun prodotto trovato.\n");
                    }

                    if (send(connect_sock, buffer, strlen(buffer),0) < 0){
                        perror("errore.\n");
                        exit(1);
                    }
                    azzera_buffer(buffer);
                }
            }
        }
        close(connect_sock);
    }
}


int create_socket_server (int sock,struct sockaddr_in srvr, int port_num){
    printf("[+] - Avvio del server\n");
    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0){
        perror("[-] - Errore Socket\n");
        exit(1);
    }

    srvr.sin_family = AF_INET;
    srvr.sin_port = htons(port_num);
    srvr.sin_addr.s_addr = htonl(INADDR_ANY);

    printf("[+] - Socket creato correttamente.\n");
    if (bind(sock, (struct sockaddr *) &srvr, sizeof(srvr)) < 0){
        perror("[-] - Errore binding.\n");
        exit(1);
    }

    if (listen(sock, PORT) < 0){
        perror("[-] Errore nell' ascolto.\n");
        exit(1);
    }

    return sock;
}

void azzera_buffer (char* buff){
    int i = 0;
    while (i < 1024){
        buff[i] = '\0';
        i++;
    }
}

struct product_list *crea_lista(){
    struct product_list *testa = NULL;
    struct product_list *ultimo = NULL;
    struct product_list *punt;
    int i = 0;


    for(i=0;i<5;i++){
        punt = (struct product_list*) malloc(sizeof(struct product_list));
        punt -> nome = (char *) malloc(50 * sizeof(char));
        punt -> negozio = (char *) malloc(50 * sizeof(char));
        punt -> prezzo = (char *) malloc(6 * sizeof(char));
        if ( i == 0 ){
            strcpy(punt -> nome, ("Prodotto 1"));
            strcpy(punt -> negozio, ("Negozio 1"));
            strcpy(punt -> prezzo, ("5,00€"));
        } else if ( i == 1 ){
            strcpy(punt -> nome, ("Prodotto 2"));
            strcpy(punt -> negozio, ("Negozio 2"));
            strcpy(punt -> prezzo, ("5,00€"));
        } else if ( i == 2 ){
            strcpy(punt -> nome, ("Prodotto 3"));
            strcpy(punt -> negozio, ("Negozio 3"));
            strcpy(punt -> prezzo, ("5,00€"));
        } else if ( i == 3 ){
            strcpy(punt -> nome, ("Prodotto 4"));
            strcpy(punt -> negozio, ("Negozio 4"));
            strcpy(punt -> prezzo, ("5,00€"));
        } else {
            strcpy(punt -> nome, ("Prodotto 5"));
            strcpy(punt -> negozio, ("Negozio 5"));
            strcpy(punt -> prezzo, ("5,00€"));
        }

        /*strcpy(punt -> nome, ("Prodotto"));
        strcpy(punt -> negozio, ("Negozio"));
        strcpy(punt -> prezzo, ("5,00€"));*/

        if (testa == NULL){
            testa = punt;
            ultimo = punt;
        }
        else{
            ultimo -> prox = punt;
            ultimo = punt;
        }
    }
    return testa;
}

int conta_elem(struct product_list *list){
    int count = 0;
    struct product_list *punt;

    punt = list;

    while (punt != NULL){
        count++;
        punt = punt -> prox;
    }

    return count;
}

void encoder (char* encodedStr, char* nom, char* neg, char* price){
    strcpy(encodedStr, nom);
    *strcat(encodedStr, "|");
    *strcat(encodedStr, neg);
    *strcat(encodedStr, "|");
    *strcat(encodedStr, price);
    *strcat(encodedStr, "|");
    //printf("%s\n", encodedStr);
}

void decoder2 (char* buff, char* nom, char* neg, char* addr){

    int i=0,j=0, verify_nom=0, verify_neg=0, verify_pirce=0;
    char *index = '\0';

    index = (char *) malloc(100 * sizeof(char));

    while (buff[i] != '\0'){
        if (buff[i] == '|'){
            if(verify_nom == 0){
                strcpy(nom, index);
                verify_nom = 1;
                azzera_buffer(index);
                j=0;
            } else if( verify_neg == 0){
                strcpy(neg, index);
                verify_neg = 1;
                azzera_buffer(index);
                j=0;
            } else if (verify_pirce == 0){
                strcpy(addr, index);
                verify_pirce = 1;
                j=0;
            }
            i++;
        }
        index[j] = buff[i];
        j++;
        i++;
    }

    free(index);
}

void inserisci_coda (struct product_list *pl, struct product_list *punt){
    struct product_list *testa = pl;
    while (pl->prox != NULL){
        pl = pl->prox;
    }
    pl->prox = punt;
    pl = testa;
    int count = conta_elem(pl);
}

struct product_list* elimina_elem(struct product_list *pl, char* buff, int found) {
    struct product_list *prev = NULL;
    struct product_list *punt = NULL;
    struct product_list *testa = pl;

    do {
        if (strcmp(pl->nome, buff) == 0) {
            if (prev == NULL) {
                punt = pl;
                pl = pl->prox;
                testa = pl;
                punt ='\0';
                found = 1;
                break;
            } else if (pl->prox == NULL) {
                punt = pl;
                prev->prox = NULL;
                punt = '\0';
                found = 1;
                break;
            } else {
                punt = pl;
                prev->prox = pl->prox;
                punt = '\0';
                found = 1;
                break;
            }
        }
        prev = pl;
        pl = pl->prox;
    }while (pl->prox != NULL);
    return testa;
}