#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <string.h>

#define PORT 4455

void azzera_buffer(char*);
struct product_list decoder (char*, struct product_list);

struct product_list {
    char *nome;
    char *negozio;
    char *prezzo;
};

int main() {

    int risposta, risposta2, clientSocket, n=0, verify=0, *num_elem=0, num2, blocca=0;
    struct sockaddr_in servaddr;
    struct product_list pl[100], al[50];
    char *buffer, aNome[64];

    fflush(stdin);
    printf("[+] - Avvio dell' applicazione.\n");

    memset(&servaddr, '\0', sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(PORT);
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);

    buffer = (char *)malloc(1024*sizeof(char));

    for( ; ; ){
        printf("\n1) Ottieni Lista prodotti \n2) Acquista \n3) Visualizza Lista acquisti \n4) Esci\n[+] - Cosa vuoi fare?");

        scanf("%d", &risposta);
        if(risposta < 1 || risposta > 4){
            perror("[-] - Opzione non disponibile o non valida.\n");
            scanf("%d", &risposta);
        }

        //Ottiene la lista dei prodotti dal Server M tramite il Server C.
        if(risposta == 1) {

            if ((clientSocket = socket(AF_INET, SOCK_STREAM,0)) < 0){
                perror("[-] - Errore Socket!\n");
                exit(1);
            }

            if (connect(clientSocket, (struct sockaddr *) &servaddr, sizeof(servaddr)) < 0) {
                perror("[-] - Errore di connessione!\n");
                exit(1);
            }

            azzera_buffer(buffer);

            if (recv(clientSocket, buffer, 1024, 0) < 0){
                perror("[-] - Errore di ricezione");
                exit(1);
            }

            num_elem = (int*) buffer;
            num2 = *num_elem;

            azzera_buffer(buffer);
            strcpy(buffer,"Pronto a ricevere i dati.\n");

            if (send(clientSocket, buffer, strlen(buffer), 0) < 0){
                perror("[-] - Errore durante l'invio");
                exit(1);
            }

            for (int i=0; i<num2; i++){

                if (recv(clientSocket, buffer, 1024, 0) < 0){
                    perror("errore\n");
                    exit(1);
                }

                pl[i].nome = (char *) malloc(50*sizeof(char));
                pl[i].negozio = (char *) malloc(50*sizeof(char));
                pl[i].prezzo = (char *) malloc(6*sizeof(char));
                pl[i]=decoder(buffer, pl[i]);

                azzera_buffer(buffer);
                strcpy(buffer,"Prodotto ricevuto.");

                if(send(clientSocket, buffer, strlen(buffer), 0) < 0){
                    perror("errore\n");
                    exit(1);
                }
            }

            for (int i=0; i<num2; i++) {
                printf("Nome Prodotto: %s\t Negozio: %s\t Prezzo: %s\n", pl[i].nome, pl[i].negozio, pl[i].prezzo);
            }

            blocca = 1;

            close(clientSocket);
        }

        if (risposta == 2){
            if (blocca == 0){
                perror("[!] - Devi prima visualizzare la lista dei prodotti.\n");
            } else {
                azzera_buffer(aNome);
                printf("\n[+] - Inserire il nome del prodotto da acquistare: ");
                scanf(" %[^\n]", aNome);

                for (int i=0;i<num2;i++) {
                    if (strcmp(aNome, pl[i].nome) == 0){
                        verify = 1;
                        printf("[+] - Vuoi comprare il prodotto: %s, Prezzo: %s del Negozio: %s?\n1)Si\n2)No\n", pl[i].nome, pl[i].prezzo, pl[i].negozio);
                        scanf("%d", &risposta2);
                        if (risposta2 == 1){
                            al[n] = pl[i];
                            printf("[+] - Acquisto Effettuato.\n");
                            printf("Nome: %s,\tNegozio: %s,\tPrezzo: %s\n", al[n].nome, al[n].negozio, al[n].prezzo);
                            n++;
                            break;
                        } else {
                            printf("[+] - Acquisto non effettuato.\n");
                        }
                    }
                }
                if (verify == 0){
                    perror("[!] - Prodotto non trovato!\n");
                    verify = 0;
                }
            }
        }

        if(risposta == 3){
            for (int i=0; i<n; i++) {
                printf("Nome: %s,\tNegozio: %s,\tPrezzo: %s\n", al[i].nome, al[i].negozio, al[i].prezzo);
            }
        }

        if (risposta == 4){
            exit(0);
        }
    }
}

void azzera_buffer (char* buff){
    int i = 0;
    while (i < 1024){
        buff[i] = '\0';
        i++;
    }
}

struct product_list decoder (char* buff, struct product_list punt){
    int i=0,j=0, verify_nom=0, verify_neg=0, verify_pirce=0;
    char *index, *fnome, *fnegozio, *fprezzo;

    index = (char *)malloc(50*sizeof(char));
    fnome = (char *)malloc(50*sizeof(char));
    fnegozio = (char *)malloc(50*sizeof(char));
    fprezzo = (char *)malloc(6*sizeof(char));

    while (buff[i] != '\0'){
        if (buff[i] == '|'){
            if(verify_nom == 0){
                strcpy(fnome, index);
                verify_nom = 1;
                index = '\0';
                index = (char *)malloc(50*sizeof(char));
                j=0;
            } else if( verify_neg == 0){
                strcpy(fnegozio, index);
                verify_neg = 1;
                index = '\0';
                index = (char *)malloc(50*sizeof(char));
                j=0;
            } else if (verify_pirce == 0){
                strcpy(fprezzo, index);
                verify_pirce = 1;
                index = '\0';
                index = (char *)malloc(50*sizeof(char));
                j=0;
            }
            i++;
        }
        index[j] = buff[i];
        j++;
        i++;
    }

    strcpy(punt.nome, fnome);
    strcpy(punt.negozio, fnegozio);
    strcpy(punt.prezzo, fprezzo);

    fnegozio = '\0';
    fnome = '\0';
    fprezzo = '\0';
    index = '\0';

    return punt;
}

