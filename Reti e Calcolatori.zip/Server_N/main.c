#include <stdio.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <string.h>

#define PORT 4459
#define PORT1 4456

int create_socket_server(int, struct sockaddr_in, int);
void azzera_buffer(char*);

int main() {
    int serverSocket, connectSocket, server_m_sock;
    int *num_elem=0;
    struct sockaddr_in servaddr, servMAddr, newAddr;
    socklen_t addrSize;
    pid_t childpid;
    char* buffer, *echo;

    buffer = (char *) malloc(1024 * sizeof(char));
    echo = (char *) malloc(1024 * sizeof(char));

    serverSocket = create_socket_server(serverSocket, servaddr, PORT);

    addrSize =sizeof(newAddr);

    for ( ; ; ) {
        if((connectSocket = accept(serverSocket, (struct sockaddr *) &newAddr, &addrSize)) < 0){
            perror("[-] - Errore di connessione.\n");
            exit(1);
        }

        if (childpid = fork() == 0) {

            printf("[+] - Connessione effettuata.\n");

            if (recv(connectSocket, buffer, 1024, 0) < 0) {
                perror("errore ricezione.\n");
                exit(1);
            }

            if (strcmp(buffer, "aggiungi") == 0) {
                //aggiunge negozio
                azzera_buffer(buffer);
                strcpy(buffer, "Inserire i dati del negozio.\n");

                if (send(connectSocket, buffer, strlen(buffer), 0) < 0) {
                    perror("errore invio.");
                    exit(1);
                }

                azzera_buffer(buffer);

                if (recv(connectSocket, buffer, 1024, 0) < 0) {
                    perror("errore ricezione.\n");
                    exit(1);
                }

                strcpy(echo, buffer);

                //Connessione al Server M

                if ((server_m_sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
                    perror("errore.\n");
                    exit(1);
                }

                memset(&servMAddr, '\0', sizeof(servMAddr));
                servMAddr.sin_family = AF_INET;
                servMAddr.sin_port = htons(PORT1);
                servMAddr.sin_addr.s_addr = htonl(INADDR_ANY);

                if (connect(server_m_sock, (struct sockaddr *) &servMAddr, sizeof(servMAddr)) < 0) {
                    perror("error.\n");
                    exit(1);
                }

                azzera_buffer(buffer);
                strcpy(buffer, "ServerN");

                if (send(server_m_sock, buffer, strlen(buffer), 0) < 0) {
                    perror("errore invio.\n");
                    exit(1);
                }

                azzera_buffer(buffer);

                if (recv(server_m_sock, buffer, 1024, 0) < 0) {
                    perror("errore ricev.\n");
                    exit(1);
                }

                azzera_buffer(buffer);
                strcpy(buffer, "aggiungi");

                if (send(server_m_sock, buffer, strlen(buffer), 0) < 0) {
                    perror("errore invio1.\n");
                    exit(1);
                }

                azzera_buffer(buffer);

                if (recv(server_m_sock, buffer, 1024, 0) < 0) {
                    perror("errore ricev1.\n");
                    exit(1);
                }

                azzera_buffer(buffer);
                strcpy(buffer, echo);

                if (send(server_m_sock, buffer, strlen(buffer), 0) < 0) {
                    perror("errore invio2.\n");
                    exit(1);
                }

                azzera_buffer(buffer);

                if (recv(server_m_sock, buffer, 1024, 0) < 0) {
                    perror("errore.\n");
                    exit(1);
                }

                if (send(connectSocket, buffer, strlen(buffer), 0) < 0) {
                    printf("errore.\n");
                    exit(1);
                }

                azzera_buffer(buffer);

            } else if (strcmp(buffer, "rimuovi") == 0) {
                //rimuove negozip

                azzera_buffer(buffer);

                strcpy(buffer, "Inserire il nome del negozio da eliminare.\n");

                if (send(connectSocket, buffer, strlen(buffer), 0) < 0) {
                    perror("errore invio2.\n");
                    exit(1);
                }

                azzera_buffer(buffer);

                if (recv(connectSocket, buffer, 1024, 0) < 0) {
                    perror("errore ricezione.\n");
                    exit(1);
                }

                strcpy(echo, buffer);

                //Connessione al Server M

                if ((server_m_sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
                    perror("errore.\n");
                    exit(1);
                }

                memset(&servMAddr, '\0', sizeof(servMAddr));
                servMAddr.sin_family = AF_INET;
                servMAddr.sin_port = htons(PORT1);
                servMAddr.sin_addr.s_addr = htonl(INADDR_ANY);

                if (connect(server_m_sock, (struct sockaddr *) &servMAddr, sizeof(servMAddr)) < 0) {
                    perror("error.\n");
                    exit(1);
                }

                azzera_buffer(buffer);
                strcpy(buffer, "ServerN");

                if (send(server_m_sock, buffer, strlen(buffer), 0) < 0) {
                    perror("errore invio.\n");
                    exit(1);
                }

                azzera_buffer(buffer);

                if (recv(server_m_sock, buffer, 1024, 0) < 0) {
                    perror("errore ricev.\n");
                    exit(1);
                }

                azzera_buffer(buffer);
                strcpy(buffer, "rimuovi");

                if (send(server_m_sock, buffer, strlen(buffer), 0) < 0) {
                    perror("errore invio.\n");
                    exit(1);
                }

                azzera_buffer(buffer);

                if (recv(server_m_sock, buffer, 1024, 0) < 0) {
                    perror("errore ricev.\n");
                    exit(1);
                }

                azzera_buffer(buffer);
                strcpy(buffer, echo);

                if (send(server_m_sock, buffer, strlen(buffer), 0) < 0) {
                    perror("errore invio1.\n");
                    exit(1);
                }

                azzera_buffer(buffer);

                if (recv(server_m_sock, buffer, 1024, 0) < 0) {
                    perror("errore.\n");
                    exit(1);
                }


                if (send(connectSocket, buffer, strlen(buffer), 0) < 0) {
                    perror("errore.\n");
                    exit(1);
                }

                azzera_buffer(buffer);

            } else if (strcmp(buffer, "aggiungiP") == 0) {
                //aggiunge prodotto
                azzera_buffer(buffer);
                strcpy(buffer, "Inserire i dati del Prodotto.\n");

                if (send(connectSocket, buffer, strlen(buffer), 0) < 0) {
                    perror("errore invio.");
                    exit(1);
                }

                azzera_buffer(buffer);

                if (recv(connectSocket, buffer, 1024, 0) < 0) {
                    perror("errore ricezione.\n");
                    exit(1);
                }

                strcpy(echo, buffer);

                //Connessione al Server M

                if ((server_m_sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
                    perror("errore.\n");
                    exit(1);
                }

                memset(&servMAddr, '\0', sizeof(servMAddr));
                servMAddr.sin_family = AF_INET;
                servMAddr.sin_port = htons(PORT1);
                servMAddr.sin_addr.s_addr = htonl(INADDR_ANY);

                if (connect(server_m_sock, (struct sockaddr *) &servMAddr, sizeof(servMAddr)) < 0) {
                    perror("error.\n");
                    exit(1);
                }

                azzera_buffer(buffer);
                strcpy(buffer, "ServerN");

                if (send(server_m_sock, buffer, strlen(buffer), 0) < 0) {
                    perror("errore invio.\n");
                    exit(1);
                }

                azzera_buffer(buffer);

                if (recv(server_m_sock, buffer, 1024, 0) < 0) {
                    perror("errore ricev.\n");
                    exit(1);
                }

                azzera_buffer(buffer);
                strcpy(buffer, "aggiungiP");

                if (send(server_m_sock, buffer, strlen(buffer), 0) < 0) {
                    perror("errore invio1.\n");
                    exit(1);
                }

                azzera_buffer(buffer);

                if (recv(server_m_sock, buffer, 1024, 0) < 0) {
                    perror("errore ricev1.\n");
                    exit(1);
                }

                azzera_buffer(buffer);
                strcpy(buffer, echo);

                if (send(server_m_sock, buffer, strlen(buffer), 0) < 0) {
                    perror("errore invio2.\n");
                    exit(1);
                }

                azzera_buffer(buffer);

                if (recv(server_m_sock, buffer, 1024, 0) < 0) {
                    perror("errore.\n");
                    exit(1);
                }

                if (send(connectSocket, buffer, strlen(buffer), 0) < 0) {
                    perror("errore invio2.\n");
                    exit(1);
                }

                azzera_buffer(buffer);

            } else if (strcmp(buffer, "rimuoviP") == 0) {
                //rimuove prodotto

                azzera_buffer(buffer);

                strcpy(buffer, "Inserire il nome del prodotto da eliminare.\n");

                if (send(connectSocket, buffer, strlen(buffer), 0) < 0) {
                    perror("errore invio2.\n");
                    exit(1);
                }

                azzera_buffer(buffer);

                if (recv(connectSocket, buffer, 1024, 0) < 0) {
                    perror("errore ricezione.\n");
                    exit(1);
                }

                strcpy(echo, buffer);

                //Connessione al Server M

                if ((server_m_sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
                    perror("errore.\n");
                    exit(1);
                }

                memset(&servMAddr, '\0', sizeof(servMAddr));
                servMAddr.sin_family = AF_INET;
                servMAddr.sin_port = htons(PORT1);
                servMAddr.sin_addr.s_addr = htonl(INADDR_ANY);

                if (connect(server_m_sock, (struct sockaddr *) &servMAddr, sizeof(servMAddr)) < 0) {
                    perror("error.\n");
                    exit(1);
                }

                azzera_buffer(buffer);
                strcpy(buffer, "ServerN");

                if (send(server_m_sock, buffer, strlen(buffer), 0) < 0) {
                    perror("errore invio.\n");
                    exit(1);
                }

                azzera_buffer(buffer);

                if (recv(server_m_sock, buffer, 1024, 0) < 0) {
                    perror("errore ricev.\n");
                    exit(1);
                }

                azzera_buffer(buffer);
                strcpy(buffer, "rimuoviP");

                if (send(server_m_sock, buffer, strlen(buffer), 0) < 0) {
                    perror("errore invio.\n");
                    exit(1);
                }

                azzera_buffer(buffer);

                if (recv(server_m_sock, buffer, 1024, 0) < 0) {
                    perror("errore ricev.\n");
                    exit(1);
                }

                azzera_buffer(buffer);
                strcpy(buffer, echo);

                if (send(server_m_sock, buffer, strlen(buffer), 0) < 0) {
                    perror("errore invio1.\n");
                    exit(1);
                }

                azzera_buffer(buffer);

                if (recv(server_m_sock, buffer, 1024, 0) < 0) {
                    perror("errore.\n");
                    exit(1);
                }

                if (send(connectSocket, buffer, strlen(buffer), 0) < 0) {
                    perror("errore.\n");
                    exit(1);
                }
                azzera_buffer(buffer);
            }
        }
        close(connectSocket);
    }
    return 0;
}

int create_socket_server (int sock, struct sockaddr_in srvr, int port_num){
    printf("[+] - Avvio del server\n");
    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0){
        perror("[-] - Errore Socket\n");
        exit(1);
    }

    srvr.sin_family = AF_INET;
    srvr.sin_port = htons(port_num);
    srvr.sin_addr.s_addr = htonl(INADDR_ANY);

    printf("[+] - Socket creato correttamente, in attesa di connessioni...\n");
    if (bind(sock, (struct sockaddr *) &srvr, sizeof(srvr)) < 0){
        perror("[-] - Errore binding.\n");
        exit(1);
    }

    if (listen(sock, PORT) < 0){
        perror("[-] Errore nell' ascolto.\n");
        exit(1);
    }

    return sock;
}

void azzera_buffer (char* buff){
    int i = 0;
    while (i < 1024){
        buff[i] = '\0';
        i++;
    }
}