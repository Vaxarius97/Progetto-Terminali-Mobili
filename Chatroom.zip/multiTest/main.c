#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/socket.h>
#include <netdb.h>
#include <time.h>
#include <pthread.h>

#define PORT 4423

void recv_msg_thread(void*);
void send_msg_thread(void*);
void azzera_buffer(char*);

int main() {
    int client_fd, n=0, flag=0;
    struct sockaddr_in servaddr;
    char *buffer;
    clock_t start,end;
    double tempo;


    buffer = (char *)malloc(1024 * sizeof(char));

    if((client_fd = socket(AF_INET, SOCK_STREAM, 0)) <0){
        perror("client.");
        exit(EXIT_FAILURE);
    }

    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(PORT);
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);


    if (connect(client_fd, (struct sockaddr*)& servaddr, sizeof (servaddr)) < 0){
        perror("connessione.");
        exit(EXIT_FAILURE);
    }

    scanf(" %[^\n]", buffer);

    if(send(client_fd,buffer,strlen(buffer),0) < 0){
        perror("sending");
        exit(EXIT_FAILURE);
    }

    pthread_t recive_thread;
    if (pthread_create(&recive_thread, NULL, &recv_msg_thread, (void *)client_fd) != 0){
        perror("pthread_recive.");
        exit(EXIT_FAILURE);
    }

    pthread_t send_thread;
    if (pthread_create(&send_thread, NULL, &send_msg_thread, (void *)client_fd) != 0){
        perror("pthread_recive.");
        exit(EXIT_FAILURE);
    }

    while (1){
        if (flag){
            printf("\nBye\n");
            break;
        }
    }

    close(client_fd);
    end=clock();
    tempo=((double)(end-start))/CLOCKS_PER_SEC;
    printf("\n%f", tempo);
}

void recv_msg_thread(void *p_connfd){

    char *buff = (char*)malloc(1024 * sizeof(char));
    int *connfd = (int*) p_connfd;
    
    while (1){
        clock_t start = clock();
        
        if (recv(connfd, buff, 1024, 0) < 0){
            perror("recive.");
            exit(EXIT_FAILURE);
        }

        puts(buff);
        azzera_buffer(buff);

        clock_t end = clock();
        double tempo = ((double) (end - start)) / CLOCKS_PER_SEC;
        printf("\n%f\n", tempo);
    }

}

void send_msg_thread(void *p_connfd){
    char *buff1 = (char *) malloc(1024 * sizeof(char));
    int *connfd = (int *) p_connfd;

    while (1){
        azzera_buffer(buff1);

        scanf(" %[^\n]", buff1);

        if (send(connfd, buff1, strlen(buff1), 0) < 0){
            perror("Sending.");
            exit(EXIT_FAILURE);
        }

        azzera_buffer(buff1);
    }
}

void azzera_buffer (char* buff){
    int i = 0;
    while (i < 1024){
        buff[i] = '\0';
        i++;
    }
}
