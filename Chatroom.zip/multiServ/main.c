#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/socket.h>
#include <netdb.h>
#include <sys/types.h>
#include <pthread.h>

#define PORT 4423

void azzera_buffer(char *);


typedef struct clientStruct{
    int id;
    char name[32];
    int sock_fd;

} client_T;

client_T clients[10];
pthread_mutex_t client_mutex = PTHREAD_MUTEX_INITIALIZER;

void queue_add(client_T*);
void queue_remove(int);
void send_message(char*,int);
void * handle_connection(void*);
void * handle_client(void*);

int main() {
    int serv_fd, client_fd, count = 1;
    struct sockaddr_in servaddr, clientaddr;
    char *buff1;


    fflush(stdin);

    if ((serv_fd = socket(AF_INET,SOCK_STREAM,0)) < 0){
        perror("socket.");
        exit(EXIT_FAILURE);
    }

    int enable = 1;
    setsockopt(serv_fd,SOL_SOCKET, SO_REUSEADDR, &enable ,sizeof (int));

    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    servaddr.sin_port = htons(PORT);

    if (bind(serv_fd, (struct sockaddr *)& servaddr, sizeof servaddr) < 0){
        perror("binding");
        exit(EXIT_FAILURE);
    }

    if (listen(serv_fd, 10)){
        perror("listen");
        exit(EXIT_FAILURE);
    }


    puts("Server in ascolto...");

    while (1){

        if ((client_fd = accept(serv_fd, (struct sockaddr*)NULL, NULL)) < 0){
            perror("accept");
            exit(EXIT_FAILURE);
        }

        client_T *cli = (client_T *) malloc(sizeof (client_T));

        cli->sock_fd = client_fd;
        strcpy(cli->name, "raimondo");
        cli->id = count;
        count++;

        queue_add(cli);

        pthread_t tid;
        pthread_create(&tid, NULL, &handle_client, (void*)cli);
    }
}

void * handle_connection (void *p_client_sock){

    //tmp = (char*) malloc(1024 * sizeof(char));
    char *buffer = (char*) malloc(1024 * sizeof (char));

    int client_sock = *((int*)p_client_sock);
    free(p_client_sock);
    if(recv(client_sock, buffer, 1024, 0) < 0){
        perror("recive");
        exit(EXIT_FAILURE);
    }


    strcpy(buffer, "Benvenuto nel Server!.\n");
    //strcpy(buffer, tmp);

    if(send(client_sock, buffer, strlen(buffer), 0) < 0){
        perror("send");
        exit(EXIT_FAILURE);
    }

    close(client_sock);
}

void  queue_add(client_T *cli){
    pthread_mutex_lock(&client_mutex);
    for (int i = 0; i < 10; i++) {
        if (!clients[i].id){
            clients[i] = *cli;
            break;
        }
    }
    pthread_mutex_unlock(&client_mutex);
}

void * handle_client(void *p_client_T){
    client_T *cli = (client_T *) p_client_T;

    char *tmp = (char *) malloc (128 * sizeof(char));
    char *buffer = (char*) malloc (1024 * sizeof(char));

    if (recv(cli->sock_fd, buffer, 1024,0)<0){
        perror("recive.");
        exit(EXIT_FAILURE);
    }

    strcpy(cli->name, buffer);
    puts(buffer);
    strcpy(buffer,cli->name);
    strcat(buffer, " è Connesso");

    send_message(buffer,99);

    while(1){

        azzera_buffer(buffer);

        if (recv(cli->sock_fd, buffer, 1024,0)<0){
            perror("recive.");
            exit(EXIT_FAILURE);
        }

        puts(cli->name);
        puts(": ");
        puts(buffer);
        strcpy(tmp,buffer);
        azzera_buffer(buffer);
        strcpy(buffer, cli->name);
        strcat(buffer, ": ");
        strcat(buffer, tmp);

        send_message(buffer, 99);
    }
}

void azzera_buffer (char* buff){
    int i = 0;
    while (i < 1024){
        buff[i] = '\0';
        i++;
    }
}

void queue_remove(int id){
    pthread_mutex_lock(&client_mutex);
    for (int i = 0; i < 10; i++) {
        if(clients[i].id == id) {
            strcpy(clients[i].id, NULL);
            strcpy(clients[i].name, NULL);
            break;
        }
    }
    pthread_mutex_unlock(&client_mutex);
}

void send_message (char *s, int uid){
    pthread_mutex_lock(&client_mutex);

    for (int i = 0; i < 10; i++) {
        if (clients[i].id){
            if (clients[i].id != uid){
                if (send(clients[i].sock_fd, s, strlen(s), 0) < 0){
                    perror("writing");
                    exit(EXIT_FAILURE);
                }
            }
        }
    }

    pthread_mutex_unlock(&client_mutex);
}
