#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <string.h>

#define TRUE 1
#define FALSE 0
#define PORT 4455

typedef struct cliente {
    char nome[32];
    char id[5];
} cliente;

typedef struct ristorante{
    char *nome;
} ristorante;

typedef struct prodotto{
    char *nome;
    char *prezzo;
} prodotto;

void azzera_buffer(char*);
prodotto decoder (char*, prodotto);

int main() {

    int risposta, clientSocket, *num_elem=0, num2, num3;
    struct sockaddr_in servaddr;
    cliente client;
    ristorante ristoranti[5];
    prodotto prodotti_food[40], prodotti_drink[40];
    char *buffer, *tmp, *rider_ID, aNome[64];

    fflush(stdin);
    printf("[+] - Avvio dell' applicazione.\n");

    //Inserire il nome e l'Id del Client
    tmp = (char*) malloc(256 * sizeof(char));
    printf("\n[+] - Inserire il nome: ");
    scanf(" %[^\n]", tmp);
    strcpy(client.nome, tmp);
    tmp = '\0';

    tmp = (char*) malloc(256 * sizeof(char));
    printf("\n[+] - Inserire l'ID: ");
    scanf(" %[^\n]", tmp);
    strcpy(client.id, tmp);
    tmp = '\0';

    memset(&servaddr, '\0', sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(PORT);
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);

    buffer = (char *)malloc(1024*sizeof(char));
    rider_ID = (char *)malloc(5*sizeof(char));

    for( ; ; ){
        printf("\n1) Effettua Ordine \n2) Esci\n");

        scanf("%d", &risposta);
        if(risposta < 1 || risposta > 2){

            perror("[-] - Opzione non disponibile o non valida.\n");
            scanf("%d", &risposta);

        } else if(risposta == 1){

            //Ottiene la lista dei ristoranti dal Server

            if ((clientSocket = socket(AF_INET, SOCK_STREAM,0)) < 0){
                perror("[-] - Errore Socket!\n");
                exit(1);
            }

            if (connect(clientSocket, (struct sockaddr *) &servaddr, sizeof(servaddr)) < 0) {
                perror("[-] - Errore di connessione!\n");
                exit(1);
            }

            strcpy(buffer, client.nome);
            if(send(clientSocket, buffer, strlen(buffer), 0) < 0){
                perror("errore\n");
                exit(1);
            }

            if (recv(clientSocket, buffer, 1024, 0) < 0){
                perror("[-] - Errore di ricezione");
                exit(1);
            }

            azzera_buffer(buffer);
            strcpy(buffer, client.id);

            if(send(clientSocket, buffer, strlen(buffer), 0) < 0){
                perror("errore\n");
                exit(1);
            }

            azzera_buffer(buffer);
            //Numero Ristoranti
            if (recv(clientSocket, buffer, 1024, 0) < 0){
                perror("[-] - Errore di ricezione");
                exit(1);
            }

            num_elem = (int*) buffer;
            num2 = *num_elem;

            azzera_buffer(buffer);
            strcpy(buffer,"Pronto a ricevere i dati.\n");

            if(send(clientSocket, buffer, strlen(buffer), 0) < 0){
                perror("errore\n");
                exit(1);
            }

            azzera_buffer(buffer);

            //Riceve la Lista dei Ristoranti
            for (int i=0; i<num2; i++){

                if (recv(clientSocket, buffer, 1024, 0) < 0){
                    perror("errore\n");
                    exit(1);
                }

                ristoranti[i].nome = (char *) malloc(50*sizeof(char));
                strcpy(ristoranti[i].nome, buffer);

                azzera_buffer(buffer);
                strcpy(buffer,"Ristorante ricevuto.");

                if(send(clientSocket, buffer, strlen(buffer), 0) < 0){
                    perror("errore\n");
                    exit(1);
                }

                azzera_buffer(buffer);
            }

            //Visualizza ristoranti
            for (int i=0; i<num2; i++) {
                printf("Nome Ristorante: %s\n", ristoranti[i].nome);
            }

            if (recv(clientSocket, buffer, 1024, 0) < 0){
                perror("errore\n");
                exit(1);
            }

            //Scelta del ristorabte
            printf("\n%s ", buffer);
            scanf(" %[^\n]", aNome);
            int found_rist  =  FALSE;

            for (int i = 0; i < num2; i++) {
                if (strcmp(aNome, ristoranti[i].nome)==0){
                    found_rist = TRUE;
                    break ;
                }
            }

            while (found_rist == FALSE){
                printf("[!] - Ristorante non presente nella lista.\n");
                printf("[+] - Inserire un nome presente nella lista: ");
                scanf(" %[^\n]", aNome);
                for (int i = 0; i < num2; i++) {
                    if (strcmp(aNome, ristoranti[i].nome)==0){
                        found_rist = TRUE;
                        break ;
                    }
                }
            }

            azzera_buffer(buffer);
            strcpy(buffer, aNome);
            azzera_buffer(aNome);

            if(send(clientSocket, buffer, strlen(buffer), 0) < 0){
                perror("errore\n");
                exit(1);
            }

            azzera_buffer(buffer);

            //Numero Cibi
            if (recv(clientSocket, buffer, 1024, 0) < 0){
                perror("errore\n");
                exit(1);
            }

            num_elem = (int*) buffer;
            num2 = *num_elem;
            strcpy(buffer, "Pronto a ricevere i cibi.\n");

            if(send(clientSocket, buffer, strlen(buffer), 0) < 0){
                perror("errore\n");
                exit(1);
            }

            //Lista Cibi
            for (int i=0; i<num2; i++){

                if (recv(clientSocket, buffer, 1024, 0) < 0){
                    perror("errore\n");
                    exit(1);
                }

                prodotti_food[i].nome = (char *) malloc(50*sizeof(char));
                prodotti_food[i].prezzo = (char *) malloc(6*sizeof(char));
                prodotti_food[i] = decoder(buffer, prodotti_food[i]);

                azzera_buffer(buffer);
                strcpy(buffer,"Prodotto ricevuto.");

                if(send(clientSocket, buffer, strlen(buffer), 0) < 0){
                    perror("errore\n");
                    exit(1);
                }

                azzera_buffer(buffer);
            }

            if (recv(clientSocket, buffer, 1024, 0) < 0){
                perror("errore\n");
                exit(1);
            }

            if(send(clientSocket, buffer, strlen(buffer), 0) < 0){
                perror("errore\n");
                exit(1);
            }

            printf("\n");
            for (int i = 0; i < num2; i++) {
                printf("Nome cibo: %s\t Prezzo: %s\n", prodotti_food[i].nome, prodotti_food[i].prezzo);
            }

            azzera_buffer(buffer);

            //Riceve il numero delle Bibite
            if (recv(clientSocket, buffer, 1024, 0) < 0){
                perror("errore\n");
                exit(1);
            }

            num_elem = (int*) buffer;
            num3 = *num_elem;

            strcpy(buffer, "Pronto a ricevere i drink.\n");

            if(send(clientSocket, buffer, strlen(buffer), 0) < 0){
                perror("errore\n");
                exit(1);
            }

            //Lista bibite
            for (int i=0; i<num3; i++){

                if (recv(clientSocket, buffer, 1024, 0) < 0){
                    perror("errore\n");
                    exit(1);
                }

                prodotti_drink[i].nome = (char *) malloc(50*sizeof(char));
                prodotti_drink[i].prezzo = (char *) malloc(6*sizeof(char));
                prodotti_drink[i] = decoder(buffer, prodotti_drink[i]);

                azzera_buffer(buffer);
                strcpy(buffer,"Prodotto ricevuto.");

                if(send(clientSocket, buffer, strlen(buffer), 0) < 0){
                    perror("errore\n");
                    exit(1);
                }

                azzera_buffer(buffer);
            }

            printf("\n");
            for (int i = 0; i < num3; i++) {
                printf("Nome drink: %s\t Prezzo: %s\n", prodotti_food[i].nome, prodotti_food[i].prezzo);
            }

            if (recv(clientSocket, buffer, 1024, 0) < 0){
                perror("errore\n");
                exit(1);
            }

            //Effettua Ordinazione
            printf("\n%s\n", buffer);
            printf("[+] - Inserisci il nome del piatto: ");
            tmp = (char*) malloc(256 * sizeof(char));
            int found_food  =  FALSE;

            scanf(" %[^\n]", tmp);
            for (int i = 0; i < num2; i++) {
                if (strcmp(tmp, prodotti_food[i].nome)==0){
                    found_food = TRUE;
                    break ;
                }
            }

            while (found_food == FALSE){
                perror("[!] - Piatto non presente nel menù.\n");
                printf("[+] - Inserire un nome presente nella lista:");
                scanf(" %[^\n]", tmp);
                for (int i = 0; i < num2; i++) {
                    if (strcmp(tmp, prodotti_food[i].nome)==0){
                        found_food = TRUE;
                        break ;
                    }
                }
            }

            strcpy(buffer,tmp);
            strcat(buffer,"|");
            tmp = '\0';

            printf("[+] - Inserisci il nome della Bevanda: ");
            tmp = (char*) malloc(256 * sizeof(char));

            int found_drink  =  FALSE;

            scanf(" %[^\n]", tmp);
            for (int i = 0; i < num2; i++) {
                if (strcmp(tmp, prodotti_drink[i].nome)==0){
                    found_drink = TRUE;
                    break ;
                }
            }

            while (found_drink == FALSE){
                perror("[!] - Bevanda non presente nel menù.\n");
                printf("[+] - Inserire un nome presente nella lista:");
                scanf(" %[^\n]", tmp);
                for (int i = 0; i < num2; i++) {
                    if (strcmp(tmp, prodotti_drink[i].nome)==0){
                        found_drink = TRUE;
                        break ;
                    }
                }
            }

            strcat(buffer,tmp);
            strcat(buffer,"|");
            tmp = '\0';

            //Invia Ordinazione
            if(send(clientSocket, buffer, strlen(buffer), 0) < 0){
                perror("errore\n");
                exit(1);
            }

            azzera_buffer(buffer);

            puts("[+] - Ordinazione inviata. In attesa dell'ID del Rider...\n");

            //Riceve l'ID del Rider dal Corriere
            if (recv(clientSocket, buffer, 1024, 0) < 0){
                perror("errore.\n");
                exit(1);
            }

            strcpy(rider_ID, buffer);
            strcpy(buffer,client.id);

            printf("[+] - L'ID rider e': %s\n", rider_ID);
            close(clientSocket);
        }
    }
}

void azzera_buffer (char* buff){
    int i = 0;
    while (i < 1024){
        buff[i] = '\0';
        i++;
    }
}

struct prodotto decoder (char* buff, struct prodotto punt){
    int i=0,j=0, verify_nom=0, verify_pirce=0;
    char *index, *fnome, *fprezzo;

    index = (char *)malloc(50*sizeof(char));
    fnome = (char *)malloc(50*sizeof(char));
    fprezzo = (char *)malloc(6*sizeof(char));

    while (buff[i] != '\0'){
        if (buff[i] == '|'){
            if(verify_nom == 0){
                strcpy(fnome, index);
                verify_nom = 1;
                index = '\0';
                index = (char *)malloc(50*sizeof(char));
                j=0;
            } else if (verify_pirce == 0){
                strcpy(fprezzo, index);
                verify_pirce = 1;
                index = '\0';
                index = (char *)malloc(50*sizeof(char));
                j=0;
            }
            i++;
        }
        index[j] = buff[i];
        j++;
        i++;
    }

    strcpy(punt.nome, fnome);
    strcpy(punt.prezzo, fprezzo);

    fnome = '\0';
    fprezzo = '\0';
    index = '\0';

    return punt;
}
