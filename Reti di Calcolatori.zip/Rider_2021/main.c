#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <time.h>
#include <pthread.h>
#include <string.h>


#define PORT 4457
#define PORT1 4459

#define TRUE 0
#define FALSE 1



int rider_socket, port, ord_verify = FALSE, ord_gestito = FALSE, flag = TRUE ,connected = FALSE;
struct sockaddr_in rist_server;
char *buffer, *id, *rider_name, *order, *clID;

void azzera_buffer (char*);
void *recv_msg_thread(void*);
void *send_msg_thread(void*);

int main() {

    printf("[+] - Avvio applicazione Rider:\n");

    buffer = (char*) malloc(1024 * sizeof (char));
    order = (char*) malloc(64 * sizeof(char));
    rider_name = (char*) malloc(32 * sizeof(char));
    id = (char*) malloc(5 * sizeof(char));
    clID = (char*) malloc(5 * sizeof(char));

    printf("[+] - Inserire il nome del Rider: ");
    scanf("%s", rider_name);

    printf("[+] - Inserire l'id: ");
    scanf("%s", id);


    while (1){
        flag = TRUE;

        printf("[+] - A quale Ristorante vuoi Connetterti?\n1) Ristorante 1\n2) Ristorante 2\n");
        int risp = 0;
        scanf("%d", &risp);

        if (risp == 1) {
            port = PORT;
        } else if (risp == 2) {
            port = PORT1;
        } else if (risp !=1 && risp !=2){
            perror("[!] - Inserire una risposta valida.\n");
            scanf("%d", &risp);
        }

        rist_server.sin_family = AF_INET;
        rist_server.sin_port = htons(port);
        rist_server.sin_addr.s_addr = htonl(INADDR_ANY);

        if ((rider_socket = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
            perror("errore creazione socket.\n");
            exit(EXIT_FAILURE);
        }

        if (connect(rider_socket, (struct sockaddr *) &rist_server, sizeof(rist_server)) < 0){
            perror("connesisone.");
            exit(EXIT_FAILURE);
        }
        connected = TRUE;

        strcpy(buffer, rider_name);

        //Invia nome Rider al ristorante
        if (send(rider_socket, buffer, strlen(buffer), 0) < 0){
            perror("errore invio.");
            exit(EXIT_FAILURE);
        }

        azzera_buffer(buffer);

        pthread_t recive_thread;
        if (pthread_create(&recive_thread, NULL, &recv_msg_thread, (void *)rider_socket) != 0){
            perror("pthread_recive.");
            exit(EXIT_FAILURE);
        }

        pthread_t send_thread;
        if (pthread_create(&send_thread, NULL, &send_msg_thread, (void *)rider_socket) != 0){
            perror("pthread_recive.");
            exit(EXIT_FAILURE);
        }

        while (1){
            if (flag){
                printf("\nBye\n");
                break;
            }
        }

        close(rider_socket);
    }
}

void *recv_msg_thread(void *p_rider_socket){

    char *buff = (char*)malloc(1024 * sizeof(char));
    int *rider_socket_f = (int*) p_rider_socket;

    while (connected==TRUE){

        puts("[+] - Rider in attesa di ordinazione...\n");

        if (recv(rider_socket_f, buff, 1024, 0) < 0){
            perror("recive.");
            exit(EXIT_FAILURE);
        }

        strcpy(order, buff);
        azzera_buffer(buff);
        strcpy(buff, order);
        strcat(buff, "\nVuoi prenderlo in gestione\n1) SI\n2) NO\n");

        puts(buff);

        if (strncmp(buff, "ORD", 3) == 0){
            ord_verify = TRUE;

            /* Dopo aver accettato l'ordine nell' altro thread*/

            azzera_buffer(buff);

            //Riceve conferma dal server
            if (recv(rider_socket_f, buff, 1024, 0) < 0){
                perror("recive");
                exit(1);
            }

            if (strncmp(buff, "END", 3) == 0){
                ord_verify = FALSE;

                azzera_buffer(buff);
                strcpy(buff,"NO");

                if (send(rider_socket_f, buff, strlen(buff), 0) < 0){
                    perror("sending.");
                    exit(EXIT_FAILURE);
                }
            } else {
                azzera_buffer(buff);
                strcpy(buff, id);

                //Invia ID Rider
                if (send(rider_socket_f, buff, strlen(buff), 0) < 0){
                    perror("send.");
                    exit(EXIT_FAILURE);
                }

                azzera_buffer(buff);

                //Riceve L'ID del Client
                if (recv(rider_socket_f, buff, 1024, 0) < 0){
                    perror("recive");
                    exit(1);
                }

                strcpy(clID, buff);
                azzera_buffer(buff);


                puts("[+] - La consegna è stata effettuata?\n1) Si");

                int ans;
                scanf("%d", &ans);

                if (ans!=1){
                    perror("[!] - Confermare quando l'ordine è consegnato.");
                    scanf("%d", &ans);
                }

                azzera_buffer(buff);
                strcpy(buff, "Conferma consegna Ordine");

                if (send(rider_socket_f, buff, strlen(buff), 0) < 0){
                    perror("send.");
                    exit(EXIT_FAILURE);
                }

                azzera_buffer(buff);
                if (recv(rider_socket_f, buff, 1024, 0) < 0){
                    perror("recive");
                    exit(1);
                }

                puts(buff);
                azzera_buffer(buff);

                scanf("%d", &ans);
                if (ans==1){
                    strcpy(buff, "SI");

                    if (send(rider_socket_f, buff, strlen(buff), 0) < 0){
                        perror("send.");
                        exit(EXIT_FAILURE);
                    }
                } else if (ans==2){
                    //Gestione Disconnessione
                    strcpy(buff, "NO");

                    if (send(rider_socket_f, buff, strlen(buff), 0) < 0){
                        perror("send.");
                        exit(EXIT_FAILURE);
                    }

                    connected = FALSE;
                    flag = FALSE;
                }
            }
        }

        if (ord_gestito==TRUE){
            azzera_buffer(buff);
            strcpy(buff, "[+] - ");
            strcat(buff, "L'ordine e'; ");
            strcat(buff, order);
            strcat(buff, " del Cliente con l'ID: ");
            strcat(buff, clID);

            puts(buff);
            azzera_buffer(buff);
            ord_gestito = FALSE;
        } else {
            azzera_buffer(buff);
            strcpy(buff, "[+] - ");
            strcat(buff, "L'ordine; ");
            strcat(buff, order);
            strcat(buff, " e' già stato gestito da un altro Rider.");

            puts(buff);
            azzera_buffer(buff);
        }
    }
}

void *send_msg_thread(void *p_rider_socket){
    char *buff1 = (char *) malloc(1024 * sizeof(char));
    int *rider_socket_f = (int *) p_rider_socket;

    azzera_buffer(buff1);
    while (connected == TRUE){
        if (ord_verify == TRUE){

            int ans = 0;
            scanf("%d", &ans);
            if (ans == 1){
                strcpy(buff1, "SI");
            } else if (ans == 2){
                strcpy(buff1, "NO");
            }

            if (ord_verify == TRUE){
                if (send(rider_socket_f, buff1, strlen(buff1), 0) < 0){
                    perror("Sending.");
                    exit(EXIT_FAILURE);
                }
                ord_verify = FALSE;
                ord_gestito = TRUE;
            }
            azzera_buffer(buff1);
        }
    }
}

void azzera_buffer (char* buff){
    int i = 0;
    while (i < 1024){
        buff[i] = '\0';
        i++;
    }
}