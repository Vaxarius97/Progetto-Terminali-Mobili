#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <malloc.h>
#include <pthread.h>
#include <sys/socket.h>
#include <arpa/inet.h>

#define PORT 4457
#define PORT1 4456

typedef struct ristorante{
    char *nome;
} ristorante;

typedef struct prodotto{
    char *nome;
    char *prezzo;
} prodotto;

typedef struct rider{
    char nome[32];
    int id;
    int sock_fd;
} rider;

rider riders[5];
int ristSocket, connectSocket, server_sock;
int numero_prodotti = 10, count = 1, flag=0;
struct sockaddr_in ristaddr, servMAddr, newAddr;
ristorante rist;
socklen_t addrSize;
char *buffer, *cNum_elem, *order, *clID, *print_msg;
prodotto prodotti_food[10], prodotti_drink[10];

pthread_mutex_t rider_mutex = PTHREAD_MUTEX_INITIALIZER;

void azzera_buffer(char*);
void queue_add(rider*);
void queue_remove(int);
void * handle_order(void*);
void * response_handler(void*);
void * handle_rider();
void send_message (char*,int);
int create_socket_server(int, struct sockaddr_in, int);

int main() {

    for (int i=0; i<10; i++) {
        prodotti_food[i].nome = (char *)malloc(32 * sizeof(char));
        prodotti_food[i].prezzo = (char *)malloc(5 * sizeof(char));
        prodotti_drink[i].nome = (char *)malloc(32 * sizeof(char));
        prodotti_drink[i].prezzo = (char *)malloc(5 * sizeof(char));
        switch (i) {
            case 0: strcpy(prodotti_food[i].nome,"Cibo0");strcpy(prodotti_drink[i].nome,"Drink0");break;
            case 1: strcpy(prodotti_food[i].nome,"Cibo1");strcpy(prodotti_drink[i].nome,"Drink1");break;
            case 2: strcpy(prodotti_food[i].nome,"Cibo2");strcpy(prodotti_drink[i].nome,"Drink2");break;
            case 3: strcpy(prodotti_food[i].nome,"Cibo3");strcpy(prodotti_drink[i].nome,"Drink3");break;
            case 4: strcpy(prodotti_food[i].nome,"Cibo4");strcpy(prodotti_drink[i].nome,"Drink4");break;
            case 5: strcpy(prodotti_food[i].nome,"Cibo5");strcpy(prodotti_drink[i].nome,"Drink5");break;
            case 6: strcpy(prodotti_food[i].nome,"Cibo6");strcpy(prodotti_drink[i].nome,"Drink6");break;
            case 7: strcpy(prodotti_food[i].nome,"Cibo7");strcpy(prodotti_drink[i].nome,"Drink7");break;
            case 8: strcpy(prodotti_food[i].nome,"Cibo8");strcpy(prodotti_drink[i].nome,"Drink8");break;
            case 9: strcpy(prodotti_food[i].nome,"Cibo9");strcpy(prodotti_drink[i].nome,"Drink9");break;
        }
        strcpy(prodotti_food[i].prezzo, "5.00");
        strcpy(prodotti_drink[i].prezzo, "5.00");
    }

    rist.nome = (char *) malloc(64 * sizeof(char));
    order = (char *) malloc(64 * sizeof(char));
    buffer = (char *) malloc(1024 * sizeof(char));
    cNum_elem = (char *) malloc(2 * sizeof(char));
    clID = (char *) malloc(5 * sizeof(char));
    print_msg = (char *) malloc(128 * sizeof(char));

    printf("[+] - Avvio applicazione.\n");
    printf("[+] - Inserire il nome del Ristorante: ");
    scanf(" %[^\n]", rist.nome);

    ristSocket = create_socket_server(ristSocket, ristaddr, PORT);
    addrSize =sizeof(newAddr);

    for ( ; ; ) {

        //Connessione al serer
        if ((server_sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
            perror("[-] - Errore Socket!\n");
            exit(1);
        }

        memset(&servMAddr, '\0', sizeof(servMAddr));
        servMAddr.sin_family = AF_INET;
        servMAddr.sin_port = htons(PORT1);
        servMAddr.sin_addr.s_addr = htonl(INADDR_ANY);

        if (connect(server_sock, (struct sockaddr *) &servMAddr, sizeof(servMAddr)) < 0) {
            perror("[-] - Errore di connessione!\n");
            exit(1);
        }

        azzera_buffer(buffer);
        strcpy(buffer, rist.nome);

        //Invia nome al Server
        if (send(server_sock, buffer, strlen(buffer), 0) < 0){
            perror("errore invio.\n");
            exit(1);
        }

        //Attende la connessione dal Rider
        pthread_t rider_tid;
        pthread_create(&rider_tid,NULL, &handle_rider, NULL);

        pthread_t order_tid;
        pthread_create(&order_tid, NULL, &handle_order, (void*)connectSocket);

        while (1){
            if (flag){
                printf("\nBye\n");
                break;
            }
        }
    }
}

int create_socket_server (int sock, struct sockaddr_in srvr, int port_num){
    printf("[+] - Avvio del server\n");
    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0){
        perror("[-] - Errore Socket\n");
        exit(1);
    }

    srvr.sin_family = AF_INET;
    srvr.sin_port = htons(port_num);
    srvr.sin_addr.s_addr = htonl(INADDR_ANY);

    printf("[+] - Socket creato correttamente, in attesa di connessioni...\n");
    if (bind(sock, (struct sockaddr *) &srvr, sizeof(srvr)) < 0){
        perror("[-] - Errore binding.\n");
        exit(1);
    }

    if (listen(sock, PORT) < 0){
        perror("[-] Errore nell' ascolto.\n");
        exit(1);
    }

    return sock;
}

void azzera_buffer (char* buff){
    int i = 0;
    while (i < 1024){
        buff[i] = '\0';
        i++;
    }
}

void * handle_order(void *p_coneectSocket){
    while (1){

        int *connSock = (int *) p_coneectSocket;
        azzera_buffer(buffer);

        //Rchiesta numero cibi
        if (recv(server_sock, buffer, 1024, 0) < 0) {
            perror("errore\n");
            exit(1);
        }

        azzera_buffer(buffer);
        cNum_elem[0] = (char *) numero_prodotti;
        strcpy(buffer, cNum_elem);

        if (send(server_sock, buffer, strlen(buffer), 0) < 0){
            perror("errore invio.\n");
            exit(1);
        }

        azzera_buffer(buffer);

        if (recv(server_sock, buffer, 1024, 0) < 0) {
            perror("errore\n");
            exit(1);
        }

        azzera_buffer(buffer);

        //Invia Cibi
        for (int i=0; i<numero_prodotti; i++){

            strcpy(buffer, prodotti_food[i].nome);
            strcat(buffer, "|");
            strcat(buffer, prodotti_food[i].prezzo);
            strcat(buffer, "|");

            if (send(server_sock, buffer, strlen(buffer), 0) < 0){
                perror("errore invio.\n");
                exit(1);
            }

            azzera_buffer(buffer);

            if (recv(server_sock, buffer, 1024, 0) < 0) {
                perror("errore\n");
                exit(1);
            }

            azzera_buffer(buffer);
        }

        strcpy(buffer, "[+] - Prodotti inviati correttamente.\n");
        if (send(server_sock, buffer, strlen(buffer), 0) < 0){
            perror("errore invio.\n");
            exit(1);
        }

        azzera_buffer(buffer);

        //Rchiesta numero drink
        if (recv(server_sock, buffer, 1024, 0) < 0) {
            perror("errore\n");
            exit(1);
        }

        azzera_buffer(buffer);
        cNum_elem[0] = (char *) numero_prodotti;
        strcpy(buffer, cNum_elem);

        if (send(server_sock, buffer, strlen(buffer), 0) < 0){
            perror("errore invio.\n");
            exit(1);
        }

        azzera_buffer(buffer);

        if (recv(server_sock, buffer, 1024, 0) < 0) {
            perror("errore\n");
            exit(1);
        }

        azzera_buffer(buffer);

        //Invia drink
        for (int i=0; i<numero_prodotti; i++){

            strcpy(buffer, prodotti_drink[i].nome);
            strcat(buffer, "|");
            strcat(buffer, prodotti_drink[i].prezzo);
            strcat(buffer, "|");

            if (send(server_sock, buffer, strlen(buffer), 0) < 0){
                perror("errore invio.\n");
                exit(1);
            }

            azzera_buffer(buffer);

            if (recv(server_sock, buffer, 1024, 0) < 0) {
                perror("errore\n");
                exit(1);
            }

            azzera_buffer(buffer);
        }

        strcpy(buffer, "[+] - Drink inviati in attesa di Ordinazione:");

        //Conferma invio liste
        if (send(server_sock, buffer, strlen(buffer), 0) < 0){
            perror("errore invio.\n");
            exit(1);
        }

        azzera_buffer(buffer);

        //Riceve ID Cient.
        if (recv(server_sock, buffer, 1024, 0) < 0) {
            perror("errore\n");
            exit(1);
        }

        strcpy(clID, buffer);

        if (send(server_sock, buffer, strlen(buffer), 0) < 0){
            perror("errore invio.\n");
            exit(1);
        }

        azzera_buffer(buffer);

        //Riceve Ordinazione.
        if (recv(server_sock, buffer, 1024, 0) < 0) {
            perror("errore\n");
            exit(1);
        }

        strcpy(order,buffer);

        while (1){
            if (count > 1){

                azzera_buffer(buffer);

                strcpy(buffer, "ORD - ");
                strcat(buffer, order);

                //Invia Ordinazione ai Rider
                send_message(buffer, 99);

                azzera_buffer(buffer);

                pthread_mutex_lock(&rider_mutex);
                int i = 0;

                while (i<5){
                    if (riders[i].id != 0){

                        rider *rid0 = (rider*) malloc(sizeof(rider));

                        rid0->sock_fd = riders[i].sock_fd;
                        strcpy(rid0->nome, riders[i].nome);
                        rid0->id = riders[i].id;

                        pthread_t response_tid;
                        pthread_create(&response_tid, NULL, &response_handler, (void*) rid0);
                    }
                    i++;
                }
                pthread_mutex_unlock(&rider_mutex);
                break;
            }
        }
    }
}

void * handle_rider(){
    while (1){
        if((connectSocket = accept(ristSocket, (struct sockaddr *) &newAddr, &addrSize)) < 0){
            perror("[-] - Errore di connessione.\n");
            exit(1);
        }

        azzera_buffer(buffer);

        if (recv(connectSocket, buffer, 1024, 0) < 0) {
            perror("errore\n");
            exit(1);
        }

        rider *rid = (rider*) malloc(sizeof(rider));

        rid->sock_fd = connectSocket;
        strcpy(rid->nome, buffer);
        rid->id = count;
        count++;

        char msg[128];
        strcpy(msg, rid->nome);
        strcat(msg, " si e' connesso.");

        puts(msg);

        queue_add(rid);
    }
}

void * response_handler(void *p_rid){
    rider *rid = (rider *) p_rid;

    if (recv(rid->sock_fd,buffer,1024,0) < 0){
        perror("recv");
        exit(EXIT_FAILURE);
    }

    if (strcmp(buffer, "SI") == 0){
        int r_id = rid->id;

        azzera_buffer(buffer);
        strcpy(buffer, "END - Ordine gia preso in gestione.");

        send_message(buffer, r_id);

        azzera_buffer(buffer);
        strcpy(buffer, "[+] - Conferma gestione ordine, in attesa dell'ID.");

        //Invia conferma al rider.
        if(send(rid->sock_fd, buffer, strlen(buffer), 0) < 0){
            perror("send.");
            exit(EXIT_FAILURE);
        }

        azzera_buffer(buffer);

        //Riceve ID Rider.
        if (recv(rid->sock_fd,buffer,1024,0) < 0){
            perror("recv");
            exit(EXIT_FAILURE);
        }

        //Invia ID Rideer al server.
        if(send(server_sock, buffer, strlen(buffer), 0) < 0){
            perror("send.");
            exit(EXIT_FAILURE);
        }

        azzera_buffer(buffer);
        strcpy(buffer,clID);

        //Invia L'ID del Client al Rider.
        if(send(rid->sock_fd, buffer, strlen(buffer), 0) < 0){
            perror("send.");
            exit(EXIT_FAILURE);
        }

        azzera_buffer(buffer);

        //Riceve confermadal rider
        if (recv(rid->sock_fd,buffer,1024,0) < 0){
            perror("recv");
            exit(EXIT_FAILURE);
        }

        puts(buffer);

        //Invia Conferma al server.
        if(send(server_sock, buffer, strlen(buffer), 0) < 0){
            perror("send.");
            exit(EXIT_FAILURE);
        }

        azzera_buffer(buffer);
        strcpy(buffer, "[+] - Vuoi rimanere connesso al nostro Ristorante?\n1)Si\n2)No");

        if (send(rid->sock_fd,buffer,strlen(buffer),0) < 0){
            perror("send");
            exit(EXIT_FAILURE);
        }

        azzera_buffer(buffer);

        if (recv(rid->sock_fd,buffer,1024,0) < 0){
            perror("recv");
            exit(EXIT_FAILURE);
        }

        if (strcmp(buffer, "NO") == 0){
            strcpy(print_msg, "[+] - ");
            strcat(print_msg, rid->nome);
            strcat(print_msg, " si e' disconnesso.");

            puts(print_msg);
            azzera_buffer(print_msg);

            queue_remove(rid->id);
        }
    }
}

void queue_add(rider *rid){

    pthread_mutex_lock(&rider_mutex);
    for (int i = 0; i < 10; i++) {
        if (!riders[i].id){
            riders[i] = *rid;
            break;
        }
    }
    pthread_mutex_unlock(&rider_mutex);
}

void queue_remove(int id){
    pthread_mutex_lock(&rider_mutex);
    for (int i = 0; i < 10; i++) {
        if(riders[i].id == id) {
            riders[i].id=0;
            riders[i].sock_fd = 0;
            azzera_buffer(riders[i].nome);
            break;
        }
    }
    pthread_mutex_unlock(&rider_mutex);
}

void send_message (char *s, int uid){
    pthread_mutex_lock(&rider_mutex);

    for (int i = 0; i < 5; i++) {
        if (riders[i].id){
            if (riders[i].id != uid){
                if (send(riders[i].sock_fd, s, strlen(s), 0) < 0){
                    perror("writing");
                    exit(EXIT_FAILURE);
                }
            }
        }
    }

    pthread_mutex_unlock(&rider_mutex);
}