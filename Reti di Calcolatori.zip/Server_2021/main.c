#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <malloc.h>
#include <sys/socket.h>
#include <arpa/inet.h>

#define PORT 4455
#define PORT1 4456
#define PORT2 4458

typedef struct ristorante{
    char *nome;
} ristorante;

void azzera_buffer(char*);
void handle_connection(char*,char*,int,int,int*);
int create_socket_server(int, struct sockaddr_in, int);

int main() {

    int serverSocket, connectSocket, clientSocket, connClientSocket, serverSocket1, connectSocket1, max_socket;
    int *num_elem=0, num_ristoranti = 0;
    struct sockaddr_in servaddr, newAddr;
    fd_set current_socket, ready_socket;
    ristorante ristoranti[5];
    socklen_t addrSize;
    char *buffer, *cNum_ristoranti, *clID, *print_msg;

    clID = (char*) malloc(5 * sizeof(char));
    cNum_ristoranti = (char *) malloc(2 * sizeof(char));
    buffer = (char *) malloc(1024 * sizeof(char));
    print_msg = (char *) malloc(256 * sizeof(char));

    printf("[+] - Avvio del server\n");

    addrSize =sizeof(newAddr);

    serverSocket = create_socket_server(serverSocket, servaddr, PORT1);
    serverSocket1 = create_socket_server(serverSocket1, servaddr, PORT2);
    clientSocket = create_socket_server(clientSocket, servaddr, PORT);

    FD_ZERO(&current_socket);
    FD_SET(clientSocket, &current_socket);

    max_socket = clientSocket;

    for( ; ; ){
        printf("[+] - Socket in ascolto. In attesa di connessioni...\n");

        if((connectSocket = accept(serverSocket, (struct sockaddr *) &newAddr, &addrSize)) < 0){
            perror("[-] - Errore di connessione.\n");
            exit(1);
        }

        azzera_buffer(buffer);

        if (recv(connectSocket, buffer, 1024, 0) < 0) {
            perror("errore");
            exit(1);
        }

        //Registra il nome del ristorante connesso
        ristoranti[0].nome = (char *) malloc(50 *sizeof (char));
        strcpy(ristoranti[0].nome, buffer);
        num_ristoranti++;

        strcpy(print_msg, "[+] - ");
        strcat(print_msg, ristoranti[0].nome);
        strcat(print_msg, " si e' connesso.");
        puts(print_msg);
        azzera_buffer(print_msg);

        if((connectSocket1 = accept(serverSocket1, (struct sockaddr *) &newAddr, &addrSize)) < 0){
            perror("[-] - Errore di connessione.\n");
            exit(1);
        }

        azzera_buffer(buffer);

        if (recv(connectSocket1, buffer, 1024, 0) < 0) {
            perror("errore");
            exit(1);
        }

        //Registra il nome del ristorante connesso
        ristoranti[1].nome = (char *) malloc(50 *sizeof (char));
        strcpy(ristoranti[1].nome, buffer);
        num_ristoranti++;

        strcpy(print_msg, "[+] - ");
        strcat(print_msg, ristoranti[1].nome);
        strcat(print_msg, " si e' connesso.");
        puts(print_msg);
        azzera_buffer(print_msg);

        for ( ; ; ) {

            ready_socket = current_socket;

            if (select(FD_SETSIZE, &ready_socket, NULL, NULL, NULL) < 0){
                perror("Select error.\n");
                exit(EXIT_FAILURE);
            }
            for (int i = 0; i <= max_socket; i++) {
                if (FD_ISSET(i, &ready_socket)){
                    if (i==clientSocket){

                        //Nuova connessione
                        if((connClientSocket = accept(clientSocket, (struct sockaddr *) &newAddr, &addrSize)) < 0){
                            perror("errore.");
                        }

                        if (connClientSocket > max_socket){
                            max_socket = connClientSocket;
                        }

                        FD_SET(connClientSocket, &current_socket);
                    } else {

                        if (recv(connClientSocket, buffer, 1024, 0) < 0) {
                            perror("errore\n");
                            exit(1);
                        }

                        if (send(connClientSocket, buffer, strlen(buffer), 0) < 0) {
                            perror("[-] - Errore di scrittura.\n");
                            exit(1);
                        }

                        azzera_buffer(buffer);

                        if (recv(connClientSocket, buffer, 1024, 0) < 0) {
                            perror("errore\n");
                            exit(1);
                        }

                        strcpy(clID, buffer);

                        azzera_buffer(buffer);

                        cNum_ristoranti[0] = (char *) num_ristoranti;
                        strcpy(buffer, cNum_ristoranti);

                        if (send(connClientSocket, buffer, strlen(buffer), 0) < 0) {
                            perror("[-] - Errore di scrittura.\n");
                            exit(1);
                        }

                        azzera_buffer(buffer);

                        if (recv(connClientSocket, buffer, 1024, 0) < 0) {
                            perror("errore\n");
                            exit(1);
                        }

                        azzera_buffer(buffer);

                        for (int i = 0; i < num_ristoranti; i++) {

                            strcpy(buffer, ristoranti[i].nome);

                            if (send(connClientSocket, buffer, strlen(buffer), 0) < 0) {
                                perror("[-] - Errore di scrittura.\n");
                                exit(1);
                            }

                            azzera_buffer(buffer);

                            if (recv(connClientSocket, buffer, 1024, 0) < 0) {
                                perror("errore\n");
                                exit(1);
                            }

                            azzera_buffer(buffer);
                        }

                        strcpy(buffer, "[+] - Scegliere il ristorante;");

                        //Aspetta la scelta del ristorante
                        if (send(connClientSocket, buffer, strlen(buffer), 0) < 0) {
                            perror("[-] - Errore di scrittura.\n");
                            exit(1);
                        }

                        azzera_buffer(buffer);

                        if (recv(connClientSocket, buffer, 1024, 0) < 0) {
                            perror("errore\n");
                            exit(1);
                        }

                        for (int i = 0; i < num_ristoranti; i++) {
                            if (strcmp(buffer,ristoranti[i].nome) == 0){
                                if (i==0){
                                    handle_connection(buffer,clID, connectSocket, connClientSocket, num_elem);
                                } else if (i==1){
                                    handle_connection(buffer,clID , connectSocket1, connClientSocket, num_elem);
                                }
                            }
                        }
                        azzera_buffer(buffer);
                        FD_CLR(i, &current_socket);
                    }
                }
            }
        }
    }
}

int create_socket_server (int sock, struct sockaddr_in srvr, int port_num){

    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0){
        perror("[-] - Errore Socket\n");
        exit(1);
    }

    srvr.sin_family = AF_INET;
    srvr.sin_port = htons(port_num);
    srvr.sin_addr.s_addr = htonl(INADDR_ANY);

    printf("[+] - Socket creato correttamente\n");
    if (bind(sock, (struct sockaddr *) &srvr, sizeof(srvr)) < 0){
        perror("[-] - Errore binding.\n");
        exit(1);
    }

    if (listen(sock, PORT) < 0){
        perror("[-] Errore nell' ascolto.\n");
        exit(1);
    }

    return sock;
}

void azzera_buffer (char* buff){
    int i = 0;
    while (i < 1024){
        buff[i] = '\0';
        i++;
    }
}

void handle_connection(char* buffer, char *clID, int connectSocket, int connClientSocket, int *num_elem){
    azzera_buffer(buffer);
    strcpy(buffer, "richiesta cibo");

    if (send(connectSocket, buffer, strlen(buffer), 0) < 0) {
        perror("[-] - Errore di scrittura.\n");
        exit(1);
    }

    azzera_buffer(buffer);

    //Numero Cibi
    if (recv(connectSocket, buffer, 1024, 0) < 0) {
        perror("errore\n");
        exit(1);
    }

    if (send(connClientSocket, buffer, strlen(buffer), 0) < 0) {
        perror("[-] - Errore di scrittura.\n");
        exit(1);
    }

    num_elem = (int *) buffer;
    int num_food = *num_elem;

    azzera_buffer(buffer);

    if (recv(connClientSocket, buffer, 1024, 0) < 0) {
        perror("errore\n");
        exit(1);
    }

    if (send(connectSocket, buffer, strlen(buffer), 0) < 0) {
        perror("[-] - Errore di scrittura.\n");
        exit(1);
    }

    //Lista Cibi
    for (int i = 0; i < num_food; i++) {
        azzera_buffer(buffer);

        if (recv(connectSocket, buffer, 1024, 0) < 0) {
            perror("errore\n");
            exit(1);
        }
        if (send(connClientSocket, buffer, strlen(buffer), 0) < 0) {
            perror("errore\n");
            exit(1);
        }

        azzera_buffer(buffer);

        if (recv(connClientSocket, buffer, 1024, 0) < 0) {
            perror("errore\n");
            exit(1);
        }
        if (send(connectSocket, buffer, strlen(buffer), 0) < 0) {
            perror("errore\n");
            exit(1);
        }
    }

    azzera_buffer(buffer);

    if (recv(connectSocket, buffer, 1024, 0) < 0) {
        perror("errore\n");
        exit(1);
    }
    if (send(connClientSocket, buffer, strlen(buffer), 0) < 0) {
        perror("errore\n");
        exit(1);
    }

    azzera_buffer(buffer);

    if (recv(connClientSocket, buffer, 1024, 0) < 0) {
        perror("errore\n");
        exit(1);
    }
    if (send(connectSocket, buffer, strlen(buffer), 0) < 0) {
        perror("[-] - Errore di scrittura.\n");
        exit(1);
    }

    azzera_buffer(buffer);

    //Numero Drink
    if (recv(connectSocket, buffer, 1024, 0) < 0) {
        perror("errore\n");
        exit(1);
    }

    if (send(connClientSocket, buffer, strlen(buffer), 0) < 0) {
        perror("[-] - Errore di scrittura.\n");
        exit(1);
    }

    num_elem = (int *) buffer;
    int num_drinck = *num_elem;

    azzera_buffer(buffer);

    if (recv(connClientSocket, buffer, 1024, 0) < 0) {
        perror("errore\n");
        exit(1);
    }

    if (send(connectSocket, buffer, strlen(buffer), 0) < 0) {
        perror("[-] - Errore di scrittura.\n");
        exit(1);
    }

    //Lista Drink
    for (int i = 0; i < num_drinck; i++) {

        azzera_buffer(buffer);

        if (recv(connectSocket, buffer, 1024, 0) < 0) {
            perror("errore\n");
            exit(1);
        }
        if (send(connClientSocket, buffer, strlen(buffer), 0) < 0) {
            perror("errore\n");
            exit(1);
        }

        azzera_buffer(buffer);

        if (recv(connClientSocket, buffer, 1024, 0) < 0) {
            perror("errore\n");
            exit(1);
        }
        if (send(connectSocket, buffer, strlen(buffer), 0) < 0) {
            perror("errore\n");
            exit(1);
        }
    }

    azzera_buffer(buffer);

    //Richiesta Ordinazione
    if (recv(connectSocket, buffer, 1024, 0) < 0) {
        perror("errore\n");
        exit(1);
    }

    if (send(connClientSocket, buffer, strlen(buffer), 0) < 0) {
        perror("[-] - Errore di scrittura.\n");
        exit(1);
    }

    azzera_buffer(buffer);
    strcpy(buffer,clID);

    if (send(connectSocket, buffer, strlen(buffer), 0) < 0) {
        perror("errore\n");
        exit(1);
    }

    if (recv(connectSocket, buffer, 1024, 0) < 0) {
        perror("errore\n");
        exit(1);
    }
    azzera_buffer(buffer);

    //Riceve Ordinazione
    if (recv(connClientSocket, buffer, 1024, 0) < 0) {
        perror("errore\n");
        exit(1);
    }

    if (send(connectSocket, buffer, strlen(buffer), 0) < 0) {
        perror("[-] - Errore di scrittura.\n");
        exit(1);
    }

    azzera_buffer(buffer);

    //Riceve ID rider
    if (recv(connectSocket, buffer, 1024, 0) < 0) {
        perror("errore\n");
        exit(1);
    }

    //Invia al client
    if (send(connClientSocket, buffer, strlen(buffer), 0) < 0) {
        perror("[-] - Errore di scrittura.\n");
        exit(1);
    }

    azzera_buffer(buffer);

    //Riceve coferma consegna dal ristorante
    if (recv(connectSocket, buffer, 1024, 0) < 0) {
        perror("errore\n");
        exit(1);
    }
}